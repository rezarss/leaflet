const services = [
  {
    id: 1,
    name: "وایرلس",
    value: "wireless",
    icon: '/icons/antenna.webp'
    },
    {
      id: 2,
      name: "ADSL",
      value: "adsl",
      icon: '/icons/adsl.webp'
      },
      {
        id: 3,
        name: "فیبر نوری",
        value: "fiber",
        icon: '/icons/fiber.webp'
  },
];

export { services };
